# PROMPT PARA O CLAUDE — UNIDADE A-B-C-D, BASE DE CONHECIMENTO E MINERAÇÃO CONFIGURÁVEL

Atue como engenheiro de software responsável por ajustar a unidade de análise, a base de conhecimento, o ZDP, o Modelador e a mineração de dados do projeto Gérard.

Use como referência:

- o projeto Gérard atualizado;
- os relatórios de auditoria anteriores;
- `modelo_unidade_abcd_conhecimento_mineracao_configuravel_v4.json`;
- as bases atuais do ZDP e do Modelador;
- o código existente de J48, PART e Apriori.

Não invente explicações, padrões, estratégias, regras, testes ou resultados.

## 1. UNIDADE DE ANÁLISE

A unidade de análise é composta por:

- A — ação do computador;
- B — ação do usuário;
- C — perguntas explicativas disponibilizadas pelo sistema;
- D — explicações fornecidas pelo usuário.

A e B são obrigatórios.

C e D são opcionais.

As perguntas de C foram previamente elaboradas pelo pesquisador e incorporadas a uma tela do Gérard. Essa tela pode ser acionada pelo próprio usuário por meio de um botão ao lado do texto da situação-problema.

A presença física do pesquisador não é necessária.

Formas válidas:

```text
A + B
A + B + C
A + B + C + D
```

Uma unidade A+B continua válida para análise comportamental e para a base integrada do Modelador.

## 2. AÇÃO B E OS SEIS PROTOCOLOS

Cada ação B deve ser classificada em um dos seis tipos:

```text
SELECIONAR
POSICIONAR
ORIENTAR
QUANTIFICAR
CAMINHO
TEXTO
```

Definições:

- SELECIONAR: um item é escolhido a partir de um conjunto de itens.
- POSICIONAR: o mouse é posicionado em um ponto em um espaço de uma ou mais dimensões.
- ORIENTAR: um ponto é escolhido em um espaço de duas ou mais dimensões.
- QUANTIFICAR: um valor numérico é especificado.
- CAMINHO: tarefas de posicionar e orientar são realizadas sequencialmente.
- TEXTO: textos em um espaço de duas dimensões são modificados, movidos ou editados.

Cada ação B deve:

1. possuir `protocol_instance_id`;
2. possuir exatamente um `protocol_type`;
3. receber exatamente uma avaliação final:
   - `C` = correta;
   - `E` = errada;
4. produzir no máximo uma decisão efetiva do ZDP;
5. produzir no máximo uma atualização efetiva do Modelador;
6. inserir no máximo um caso comportamental;
7. usar chave de idempotência;
8. manter eventos técnicos como subeventos não pedagógicos.

Os seis nomes são tipos de protocolo, não uma sequência fixa e não significam que cada episódio deva possuir exatamente seis ações.

## 3. FUNÇÃO DAS EXPLICAÇÕES

As explicações D não são campos meramente descritivos.

Quando fornecidas, servem para compreender os motivos da ação B.

Seus padrões podem compor a base de conhecimento do ZDP e do Modelador.

Cadeia conceitual:

```text
ação B
→ avaliação C ou E
→ explicação opcional D
→ codificação ou identificação de padrões explicativos
→ atualização da base de conhecimento
→ possível utilização futura pelo ZDP
→ utilização pelo Modelador e pela mineração periódica
```

A explicação não altera retroativamente a avaliação C ou E.

Exemplo:

```text
B: usuário posicionou um valor no papel errado
Avaliação: E
D: usuário afirma que confundiu estado inicial com estado final
```

A avaliação permanece E.

O padrão explicativo pode registrar, após curadoria válida:

```text
CONFUSAO_ESTADO_INICIAL_ESTADO_FINAL
```

## 4. AUSÊNCIA DE EXPLICAÇÃO

Quando D não for preenchido:

- nenhum padrão explicativo deve ser inventado;
- nenhuma estratégia deve ser atribuída automaticamente;
- `coherence=NOT_EVALUABLE`;
- `coded_patterns=[]`;
- `detected_strategy.available=false`;
- o ZDP decide com conhecimento comportamental;
- o Modelador continua incluindo a unidade na base integrada;
- a unidade fica disponível para a próxima rodada de mineração;
- os atributos explicativos são registrados como ausentes.

Estados de explicação:

```text
NOT_OPENED
OPENED_NOT_ANSWERED
PARTIALLY_ANSWERED
ANSWERED
```

Estados de coerência:

```text
COHERENT
PARTIALLY_COHERENT
INCOHERENT
NOT_EVALUABLE
NOT_CURATED
```

Não confundir ausência com incoerência.

## 5. CURADORIA DAS EXPLICAÇÕES

Se não houver classificador automático validado:

- preservar `raw_text`;
- usar `curation_status=NOT_CURATED`;
- usar `coherence=NOT_CURATED`;
- não criar padrões;
- não identificar estratégia;
- aguardar curadoria humana ou procedimento validado.

Quando houver curadoria:

- registrar `pattern_id`;
- categoria;
- trecho de evidência;
- método de codificação;
- versão da resposta;
- responsável ou processo de validação;
- confiança, quando aplicável.

## 6. PAPEL DO ZDP

O ZDP opera com:

### Conhecimento comportamental

- protocolo;
- resultado C/E;
- categoria;
- papel semântico;
- erros;
- tentativas;
- sequência;
- feedback;
- histórico.

### Conhecimento explicativo, quando disponível

- justificativa;
- estratégia declarada;
- dúvida;
- motivo;
- padrão explicativo;
- coerência entre ação e explicação.

Quando a explicação chega depois da decisão sobre B:

- não reavaliar B;
- não aumentar erros novamente;
- não repetir a intervenção;
- armazenar o novo conhecimento;
- disponibilizá-lo para decisões futuras;
- registrar que não foi usado na decisão anterior.

## 7. PAPEL DO MODELADOR

O Modelador deve manter continuamente a base integrada atualizada.

Mesmo sem explicação, deve registrar:

- atributos comportamentais;
- status da explicação;
- valores explicativos ausentes;
- elegibilidade para mineração;
- `pending_next_mining_run=true`.

Quando houver explicação:

- preservar o texto bruto;
- vincular à unidade e à ação B;
- registrar padrões explicativos;
- atualizar o conhecimento explicativo;
- manter rastreabilidade;
- não inserir novamente o caso comportamental;
- marcar a base como alterada;
- marcar `pending_next_mining_run=true`.

Distinguir:

1. caso comportamental;
2. complemento explicativo;
3. padrão explicativo;
4. regra minerada;
5. regra operacional.

## 8. J48, PART E APRIORI — EXECUÇÃO CONFIGURÁVEL

O Modelador não deve executar J48, PART e Apriori após cada ação, unidade ou explicação.

O Modelador atualiza a base continuamente, mas a mineração ocorre apenas:

1. periodicamente, conforme configuração do pesquisador; ou
2. por acionamento manual autorizado.

Valores mínimos para `execution_mode`:

```text
MANUAL
PERIODIC
PERIODIC_WITH_MANUAL_TRIGGER
DISABLED
```

A configuração deve conter:

- `configured_by_researcher`;
- `mining_enabled`;
- `execution_mode`;
- `interval_value`;
- `interval_unit`;
- `next_run_at`;
- `manual_execution_allowed`;
- `enabled_algorithms`;
- parâmetros de cada algoritmo;
- `last_run_at`;
- `last_mining_run_id`;
- `last_dataset_version`.

Não invente periodicidade.

O pesquisador define:

- se a mineração está habilitada;
- modo;
- intervalo;
- algoritmos;
- parâmetros;
- possibilidade de execução manual.

## 9. EFEITO DE NOVOS DADOS

Nova ação B:

- atualizar base comportamental;
- incluir unidade na base integrada;
- atualizar versão da base;
- marcar `pending_next_mining_run=true`;
- não executar imediatamente J48, PART ou Apriori.

Nova explicação D:

- atualizar a unidade;
- atualizar atributos explicativos;
- revisar padrões vinculados, quando aplicável;
- atualizar versão da base;
- marcar `pending_next_mining_run=true`;
- não executar imediatamente J48, PART ou Apriori.

Edição da explicação:

- versionar a resposta;
- preservar a versão anterior;
- invalidar ou revisar padrões antigos;
- atualizar a base;
- marcar nova mineração como pendente;
- não alterar C/E;
- não aumentar erros;
- não duplicar caso.

## 10. ROTINA PERIÓDICA

A rotina deve:

1. verificar se a mineração está habilitada;
2. verificar o modo;
3. verificar o horário configurado;
4. verificar se houve mudança desde a última execução;
5. criar snapshot imutável da base;
6. atribuir `dataset_version`;
7. executar apenas algoritmos habilitados;
8. garantir que J48, PART e Apriori usem a mesma versão da base;
9. registrar parâmetros e resultados;
10. preservar execuções anteriores;
11. atualizar `last_run_at`;
12. atualizar `last_mining_run_id`;
13. limpar `pending_next_mining_run` apenas após conclusão válida.

Em caso de falha:

- não apagar a base;
- não apagar a última execução válida;
- não limpar o indicador de pendência;
- registrar o erro;
- permitir nova tentativa.

## 11. DADOS PARA MINERAÇÃO

Incluir todas as unidades elegíveis, com ou sem explicação.

Não enviar texto livre bruto diretamente aos algoritmos, salvo se já houver transformação validada.

Usar atributos estruturados, por exemplo:

- `protocol_type`;
- `evaluation`;
- `category`;
- `source_role`;
- `target_role`;
- `error_type`;
- `attempt_count`;
- `feedback_type`;
- `explanation_status`;
- `explanation_available`;
- `explanation_coherence`;
- `coded_explanation_pattern`;
- `detected_strategy`;
- `previous_error_count`.

Ausência deve ser codificada como valor ausente ou categoria explícita compatível com os algoritmos.

Não codificar ausência como:

```text
INCOHERENT
ERROR
NO_COMPREHENSION
```

## 12. TIPOS DE CONHECIMENTO

Distinguir:

```text
RAW_EXPLANATION
CODED_EXPLANATION_PATTERN
MINED_RULE
OPERATIONAL_RULE
```

Regras mineradas não se tornam automaticamente operacionais.

A incorporação deve registrar:

- origem;
- algoritmo;
- suporte;
- confiança;
- dataset_version;
- aprovação;
- agente autorizado;
- prioridade;
- data;
- responsável ou processo de validação.

## 13. ARQUIVOS DE SAÍDA

Gerar ou ajustar:

- `unidades_analise.jsonl`;
- `acoes_usuario_protocolos.jsonl`;
- `explicacoes_usuario.jsonl`;
- `padroes_explicativos.jsonl`;
- `base_integrada_modelador.arff` ou formato atual equivalente;
- `base_integrada_apriori.arff` ou formato equivalente;
- `execucoes_mineracao.jsonl`;
- `regras_mineradas.jsonl`;
- `regras_operacionais.jsonl`;
- `eventos_tecnicos.jsonl`;
- `configuracao_mineracao.json`;
- `cardinalidade_unidades_conhecimento.tsv`.

Todos devem compartilhar identificadores aplicáveis:

- `analysis_unit_id`;
- `protocol_instance_id`;
- `session_id`;
- `episode_id`;
- `user_id`;
- `case_id`;
- `dataset_version`;
- `mining_run_id`.

## 14. CARDINALIDADE

Gerar:

- unidades totais;
- ações corretas;
- ações erradas;
- explicações não abertas;
- abertas sem resposta;
- parciais;
- respondidas;
- explicações curadas;
- não curadas;
- padrões criados;
- unidades incluídas na base;
- unidades com atributos explicativos;
- unidades sem atributos explicativos;
- execuções J48;
- execuções PART;
- execuções Apriori;
- atualizações do Modelador;
- atualizações explicativas do ZDP;
- divergências.

Deve valer:

```text
protocol_instances_total
=
correct_actions + error_actions
```

E todas as unidades elegíveis devem estar na base, salvo exclusão registrada com motivo.

## 15. TESTES AUTOMATIZADOS

Criar testes permanentes para:

1. A+B ser incluída na base;
2. A+B+C+D ser incluída na base;
3. ausência produzir NOT_EVALUABLE;
4. ausência não produzir padrão;
5. ausência não inventar estratégia;
6. D atualizar base explicativa;
7. D não alterar C/E;
8. D não aumentar erros;
9. D não duplicar caso;
10. padrão manter referência ao texto;
11. edição versionar explicação;
12. edição revisar padrões;
13. nova ação não executar J48 imediatamente;
14. nova explicação não executar PART imediatamente;
15. edição não executar Apriori imediatamente;
16. nova unidade marcar pendência;
17. modo PERIODIC respeitar horário;
18. modo MANUAL exigir acionamento autorizado;
19. modo DISABLED impedir execução;
20. algoritmo desabilitado não executar;
21. mesma rodada usar a mesma dataset_version;
22. falha manter pendência;
23. execução válida atualizar last_mining_run_id;
24. execuções anteriores permanecerem preservadas;
25. unidades sem explicação continuarem incluídas;
26. regras mineradas não se tornarem operacionais automaticamente;
27. cardinalidade fechar;
28. correções anteriores permanecerem válidas.

## 16. PRESERVAÇÃO

Não remover:

- distinção canônico/reativo;
- idempotência;
- seis tipos de protocolo;
- unidade A-B-C-D;
- localização semântica;
- recálculo de coordenadas;
- rastreamento do Robot;
- correção do disparo triplo;
- validação de schema;
- logs dos agentes;
- testes anteriores;
- restauração das bases reais.

Não colocar lógica solta na `Main`.

## 17. CRITÉRIOS DE ACEITAÇÃO

A alteração estará concluída quando:

- explicações forem conhecimento opcional;
- padrões explicativos alimentarem ZDP e Modelador;
- ausência não impedir o Modelador;
- ausência não gerar inferências falsas;
- J48, PART e Apriori não rodarem a cada ação;
- mineração obedecer à configuração do pesquisador;
- nova informação apenas marcar pendência;
- execuções forem versionadas;
- falhas preservarem a base;
- regras mineradas forem separadas de regras operacionais;
- testes permanentes forem aprovados;
- não houver regressão.

## 18. ENTREGÁVEIS

Devolver:

1. projeto atualizado em ZIP;
2. arquivos JSONL e ARFF atualizados;
3. `configuracao_mineracao.json`;
4. schemas atualizados;
5. relatório técnico;
6. matriz de uso do conhecimento pelo ZDP;
7. matriz de uso do conhecimento pelo Modelador;
8. arquivos criados e modificados;
9. resultado da compilação;
10. resultado dos testes;
11. resultado da regressão;
12. exemplo com explicação;
13. exemplo sem explicação;
14. exemplo de configuração periódica;
15. exemplo de execução manual;
16. limitações restantes.

Não invente dados, explicações, padrões, estratégias, regras, testes ou resultados.