# Pacote Gérard — unidade A-B-C-D e mineração configurável

Contém o modelo JSON e o prompt para o Claude. O Modelador atualiza a base continuamente, mas J48, PART e Apriori só são executados periodicamente ou manualmente, conforme configuração do pesquisador.
